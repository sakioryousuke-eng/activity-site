# 活動サイト スターター（ドラッグ＆ドロップ用）

このフォルダの中身を **GitHubリポジトリのルート**にまとめてアップロードしてください。
- `_config.yml` … GitHub Pages（Jekyll）用設定
- `_data/pledges.yml` … 公約マスタ（ここを書き換えるとカードが更新）
- `assets/style.css` … シンプルな見た目
- `index.md` … 上部3アイコン＋公約カードの縦並び（デフォルト表示）
- `matrix/index.md` … 質問マトリクスのプレースホルダ
- `activities/index.md` … 地域活動のプレースホルダ

## 公約の更新方法
`_data/pledges.yml` の `status / percent / last_update` を編集して保存するだけです。

## Pagesの設定
Settings → Pages → Source: "Deploy from a branch" → Branch: `main/(root)`
