---
layout: default
title: 質問マトリクス（準備中）
---

<link rel="stylesheet" href="/assets/style.css">
<div class="nav">
  <a href="/#pledges">🏳️‍🌈 公約</a>
  <a href="/activities">📍 地域</a>
  <a href="/matrix">💬 質問</a>
</div>

<div class="wrapper">
  <h1>質問マトリクス</h1>
  <p>このページは次のステップで実装します。<br>
  CSV（questions.csv / pledge_links.csv）から自動生成される一覧・マトリクスを表示します。</p>
</div>
