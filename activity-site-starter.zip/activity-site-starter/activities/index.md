---
layout: default
title: 地域活動（準備中）
---

<link rel="stylesheet" href="/assets/style.css">
<div class="nav">
  <a href="/#pledges">🏳️‍🌈 公約</a>
  <a href="/activities">📍 地域</a>
  <a href="/matrix">💬 質問</a>
</div>

<div class="wrapper">
  <h1>地域活動</h1>
  <p>写真＋一言のタイムラインをここに並べます（追って雛形を提供）。</p>
</div>
